package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage  {
    private WebDriverWait wait ;

    //Creating the constructor
    public LoginPage(WebDriver driver) {
        PageFactory.initElements(driver,this);
        wait = new WebDriverWait(driver,3);
    }

    //Locators for the login page
    @FindBy(xpath = "//input[@id='username']")
    private WebElement txt_UserName;

    @FindBy(xpath = "//input[@id='email']")
    private WebElement txt_Email;

    @FindBy(xpath = "//input[@id='password']")
    private WebElement txt_Password;

    @FindBy(xpath = "//button[@id='register-submit']")
    private WebElement btn_CreateAccount;

    @FindBy(xpath = "//div[@class='message-wrapper mb-4']//div[@class='message danger']")
    private WebElement txt_InvalidData;

    @FindBy(xpath = "//div[@class='content has-text-centered']//h2")
    private WebElement txt_SuccessMessage;


    /**
     * <h2>Method to enter the user name</h2>
     * @param Username: The username
     */
    public void enterUsername(String Username){
        txt_UserName.sendKeys(Username);
    }

    /**
     * <h2>Method to enter the Email id</h2>
     * @param Email: Email address of the user
     */
    public void enterTheEmail(String Email){
        txt_Email.sendKeys(Email);
    }

    /**
     * <h2>Method to enter the Password</h2>
     * @param Password: Password to be entered
     */
    public void enterPassword(String Password){
        wait.until(ExpectedConditions.elementToBeClickable(txt_Password)).sendKeys(Password);
    }

    /**
     * <h2>Method to click on the create account button</h2>
     */
    public void clickOnCreateAccount(){
        btn_CreateAccount.click();
    }

    /**
     * <h2>Method to check whether the account is created or not</h2>
     * @param Username: Username against account creation will be validated
     */
    public void verifyAccountCreation(String Username){
        try {
            if (wait.until(ExpectedConditions.visibilityOf(txt_InvalidData)) != null) {
                String invalidText = txt_InvalidData.getText();
                if (invalidText.equals("Invalid Data")) {
                    System.out.println("Could not create the account due to invalid data input");
                    return;
                }
            }
            }catch (Exception e){
            System.out.println("No error message is available");
        }
            if (wait.until(ExpectedConditions.visibilityOf(txt_SuccessMessage)).getText().contains(Username))
                System.out.println("The account has been created and user is logged in successfully");
            else
                System.out.println("Account Creation failed due to unknown reason");
    }
}
