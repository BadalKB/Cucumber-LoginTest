package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features= {"testFeatures/Login.feature"},
        glue = {"stepDefinitions","utilityClass"},
//        plugin={"pretty"}
        plugin={"json:target/cucumber-reports/cucumber.json"}
//        strict=true
)

public class RunnerTest {
}
