package stepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pageObjects.LoginPage;
import utilityClass.Hooks;


public class LoginSteps {

    private WebDriver driver;
    private LoginPage loginPage;


    private void initializeDriver() {
        if (driver == null) {
            driver = Hooks.getDriver();
            if (driver == null) {
                throw new IllegalStateException("Driver is null in LoginSteps");
            }
        }
    }

    @Given("User is on login page")
    public void launchURL(){
        initializeDriver();
        driver.get("https://try.vikunja.io/register");
        loginPage = new LoginPage(driver);
    }

    @When("User enters username {string}")
    public void enterTheUsername(String Username){
        loginPage.enterUsername(Username);
    }

    @And("User enters Email address {string}")
    public void enterEmailAddress(String Email){
        loginPage.enterTheEmail(Email);
    }

    @And("Enters the password {string}")
    public void enterPassword(String Password){
        loginPage.enterPassword(Password);
    }

    @Then("User clicks on create account")
    public void clickCreateAccount(){
        loginPage.clickOnCreateAccount();
    }

    @Then("Verify whether the account is created or not for the user {string}")
    public void verifyAccountCreation(String UserName){
        loginPage.verifyAccountCreation(UserName);

    }

}
