package utilityClass;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;

public class Hooks {

    private static WebDriver driver;

    /**
     * <h2>This method will be executed before each scenario</h2>
     */
    @Before
    public void driverSetUp() {
        if (driver == null) {
            System.setProperty("webdriver.chrome.driver", "D:/Selenium/Automation/driver/chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            System.out.println("Initialized the WebDriver");
        }
    }

    /**
     * <h2>This method will be executed after each scenario</h2>
     */
    @After
    public void closeBrowser(Scenario scenario) {
        if (driver != null) {
            if (scenario.isFailed()) {
                TakesScreenshot screenshot = (TakesScreenshot) driver;
                File srcFile = screenshot.getScreenshotAs(OutputType.FILE);
                String screenshotPath = "target/Screenshots/" + scenario.getName() + ".png";
                File destFile = new File(screenshotPath);

                try {
                    FileUtils.copyFile(srcFile, destFile);
                    System.out.println("Screenshot saved to: " + screenshotPath);
                } catch (IOException e) {
                    System.err.println("Failed to save screenshot: " + e.getMessage());
                }

            } else {
                driver.quit();
                driver = null;
            }
        }
    }


    /**
     * <h2>Static method to return the driver instance</h2>
     * @return: To return the webDriver instance
     */
    public static WebDriver getDriver(){
        if(driver == null) {
            System.setProperty("webdriver.chrome.driver", "D:/Selenium/Automation/driver/chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
        }
        return driver;
    }

}
