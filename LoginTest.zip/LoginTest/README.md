<h2>Selenium-Cucumber-Java</h2>

<h4>This repository contains a project and 
libraries that demonstrate how to use selenium-cucumber-java, a 
BDD (Behavior-Driven Development) framework with Cucumber (v7.14.0) 
and Java. The projects showcase automation script development for trying to create
an account in the "vikunja" site. This includes both positive and 
negative scenarios. Additionally, it offers the ability to capture screenshots for 
tests and generate error shots for failed test cases.</h4>

<h2>Installation & Prerequisites:</h2>
1.JDK (Ensure that the Java class path is properly set)</br>
2.Maven (Ensure that the .m2 class path is properly set)</br>
3.IDE</br>
4.Required Eclipse Plugins:</br>
    <t>a.Maven</br>
    b.Cucumber</br>
5.Browser driver (Ensure that you have the appropriate browser driver for your desired browser and that the class path is correctly configured)</br>

<h2>Framework Setup:</h2>
1. Install Java and set path.
2. Install Maven and set path.
3. Clone respective repository or download zip.

<h2>Framework Architecture:</h2>
1. /testFeatures -  The cucumber features file (files .feature ext) is available here.
2. src/test/java/stepDefinitions - The required step definition file goes here.
3. src/test/java/pageObjects - All the page objects and element locators related to the feature file available here.
4. src/test/java/RunnerTest - The runner class where you can mention the glue code location. Hooks where you can configure all before and after test settings Hooks.java
5. src/test/java/utilityClass - This package contains the class where the code for intializing driver instances for respective driver is available.
6. target/surefire-reports - The xml report will be saved here
7. target/Screenshots - The screenshot for the failed scenario will be saved here

<h2>To run the test:</h2>
The below any of the steps can be followed to run the test.
1. In the IDE(here I am using Intellij) console, go to the feature fil-> Right CLick -> Run Scenario.
2. mvn clean test - To run in the terminal







